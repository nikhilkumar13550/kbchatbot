# =============================================================================
# IGP Automation — OAR Payment Email Reader & Tracker
# =============================================================================
# What this script does:
#   1. Connects to Outlook desktop app
#   2. Opens the IGP OAR Payments/JHancock/Manulife shared mailbox
#   3. Reads all UNREAD emails with subject containing "Payment Received : OAR"
#   4. Extracts: NP Name, Currency, Amount, Tx Code, Pay Date, Bank Ref, Sender
#   5. Appends a new row to the OAR Payment Tracker Excel file on the LAN
#   6. Marks each processed email as READ so it is not processed again
#   7. Logs every action to a daily log file for audit purposes
#
# Run manually:  python oar_payment_tracker.py
# Scheduled:     Windows Task Scheduler — see README for setup steps
# =============================================================================

import re
import os
import logging
from datetime import datetime
from pathlib import Path

import win32com.client
import openpyxl
from openpyxl.styles import PatternFill, Font, Alignment, Border, Side
from dotenv import load_dotenv

# -----------------------------------------------------------------------------
# LOAD CONFIGURATION FROM .env FILE
# -----------------------------------------------------------------------------
# Create a file called .env in the same folder as this script with:
#
#   MAILBOX_NAME=IGP OAR Payments/JHancock/Manulife
#   TRACKER_PATH=\\server\IGP\OAR\OAR_Payment_Tracker.xlsx
#   LOG_FOLDER=\\server\IGP\OAR\Logs
#
# If no .env file exists, the defaults below are used.
# -----------------------------------------------------------------------------
load_dotenv()

MAILBOX_NAME  = os.getenv("MAILBOX_NAME",  "IGP OAR Payments/JHancock/Manulife")
TRACKER_PATH  = os.getenv("TRACKER_PATH",  r"C:\IGP\OAR\OAR_Payment_Tracker.xlsx")
LOG_FOLDER    = os.getenv("LOG_FOLDER",    r"C:\IGP\OAR\Logs")
SHEET_NAME    = "OAR Payments"

# -----------------------------------------------------------------------------
# LOGGING SETUP
# -----------------------------------------------------------------------------
# Creates a new log file each day: OAR_Payment_Log_2026-10-26.txt
# Logs every email processed, every row written, and any errors.
# -----------------------------------------------------------------------------
Path(LOG_FOLDER).mkdir(parents=True, exist_ok=True)

log_file = Path(LOG_FOLDER) / f"OAR_Payment_Log_{datetime.now().strftime('%Y-%m-%d')}.txt"

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
    handlers=[
        logging.FileHandler(log_file, encoding="utf-8"),
        logging.StreamHandler()          # also prints to console
    ]
)

log = logging.getLogger(__name__)


# =============================================================================
# STEP 1 — CONNECT TO OUTLOOK AND OPEN THE SHARED MAILBOX
# =============================================================================

def get_oar_inbox():
    """
    Connect to the Outlook desktop app via COM and return the Inbox folder
    of the IGP OAR Payments shared mailbox.
    Raises a clear error if Outlook is not open or the mailbox is not found.
    """
    log.info("Connecting to Outlook...")
    try:
        outlook   = win32com.client.Dispatch("Outlook.Application")
        namespace = outlook.GetNamespace("MAPI")
    except Exception as e:
        log.error(f"Cannot connect to Outlook. Is Outlook open? Error: {e}")
        raise

    # Walk all accounts visible in Outlook to find the shared mailbox
    for folder in namespace.Folders:
        if MAILBOX_NAME.lower() in folder.Name.lower():
            log.info(f"Found mailbox: {folder.Name}")
            try:
                return folder.Folders["Inbox"]
            except Exception:
                # Some setups use a different subfolder name
                return folder.Folders.Item(1)

    raise ValueError(
        f"Mailbox '{MAILBOX_NAME}' not found in Outlook. "
        f"Check that it is added and visible in the Outlook profile on this machine."
    )


# =============================================================================
# STEP 2 — EXTRACT DATA FROM A SINGLE OAR PAYMENT EMAIL
# =============================================================================

def extract_oar_payment(email) -> dict | None:
    """
    Parse one Outlook email item and return a dict of extracted fields.
    Returns None if the email does not look like an OAR payment notification.

    Expected subject format:
        Payment Received : OAR AG BELGIUM USD 2,283,934.81
        Payment Received : OAR <NP NAME> <CURRENCY> <AMOUNT>
    """
    subject = email.Subject or ""
    body    = email.Body    or ""

    # ── Guard: only process OAR payment notification emails ──────────────────
    if "Payment Received" not in subject or "OAR" not in subject:
        log.debug(f"Skipping non-OAR email: {subject[:80]}")
        return None

    log.info(f"Processing email: {subject[:100]}")

    # ── Extract from Subject Line ─────────────────────────────────────────────
    # Pattern: "Payment Received : OAR <NP NAME> <CURRENCY> <AMOUNT>"
    subj_pattern = re.search(
        r"Payment Received\s*[:\-]\s*(?:OAR\s+)?(.+?)\s+"
        r"(USD|EUR|GBP|CAD|AUD|CHF|JPY|SGD|HKD|SEK|NOK|DKK)\s+"
        r"([\d,\.]+)",
        subject, re.IGNORECASE
    )

    np_name  = subj_pattern.group(1).strip() if subj_pattern else "UNKNOWN"
    currency = subj_pattern.group(2).strip() if subj_pattern else "UNKNOWN"
    amount_str = subj_pattern.group(3).replace(",", "") if subj_pattern else "0"
    try:
        amount = float(amount_str)
    except ValueError:
        amount = 0.0

    # ── Extract from Email Body ───────────────────────────────────────────────

    # Transaction code — e.g. US004, BE012, NL003
    tx_match = re.search(r"\b([A-Z]{2}\d{3,4})\b", body)
    tx_code  = tx_match.group(1) if tx_match else ""

    # Payment date — first MM/DD/YYYY date in the body
    date_match = re.search(r"(\d{2}/\d{2}/\d{4})", body)
    pay_date   = date_match.group(1) if date_match else ""

    # Wire type — WIRE IN, WIRE OUT, ACH, SWIFT
    wire_match = re.search(r"TYPE\s*:\s*(WIRE IN|WIRE OUT|WIRE|ACH|SWIFT)", body, re.IGNORECASE)
    wire_type  = wire_match.group(1).upper() if wire_match else ""

    # Bank reference / ETR number
    etr_match = re.search(r"ETR\s*:\s*([\w\-]+)", body, re.IGNORECASE)
    bank_ref  = etr_match.group(1) if etr_match else ""

    # BNP/FORTIS bank identifier (secondary reference if ETR not found)
    if not bank_ref:
        bk_match = re.search(r"BK\s*:\s*ID\s*:\s*(\S+)", body, re.IGNORECASE)
        bank_ref = bk_match.group(1) if bk_match else ""

    # ── Sender details ────────────────────────────────────────────────────────
    sender_name  = email.SenderName         or ""
    sender_email = email.SenderEmailAddress or ""

    # ── Email received date/time ──────────────────────────────────────────────
    received_dt = email.ReceivedTime
    received_str = received_dt.strftime("%Y-%m-%d %H:%M") if received_dt else ""

    return {
        "logged_at"    : datetime.now().strftime("%Y-%m-%d %H:%M"),
        "received_date": received_str,
        "np_name"      : np_name,
        "currency"     : currency,
        "amount"       : amount,
        "tx_code"      : tx_code,
        "pay_date"     : pay_date,
        "wire_type"    : wire_type,
        "bank_ref"     : bank_ref,
        "sender_name"  : sender_name,
        "sender_email" : sender_email,
        "status"       : "Pending",
        "notes"        : "",
    }


# =============================================================================
# STEP 3 — WRITE A ROW TO THE OAR PAYMENT TRACKER EXCEL FILE
# =============================================================================

# Column order in the tracker sheet
COLUMNS = [
    "Logged At",
    "Received Date",
    "NP Name",
    "Currency",
    "Amount",
    "Tx Code",
    "Pay Date",
    "Wire Type",
    "Bank Reference",
    "Sender Name",
    "Sender Email",
    "Status",
    "Notes",
]

# Map dict keys → column index (1-based)
COL_MAP = {
    "logged_at"    : 1,
    "received_date": 2,
    "np_name"      : 3,
    "currency"     : 4,
    "amount"       : 5,
    "tx_code"      : 6,
    "pay_date"     : 7,
    "wire_type"    : 8,
    "bank_ref"     : 9,
    "sender_name"  : 10,
    "sender_email" : 11,
    "status"       : 12,
    "notes"        : 13,
}


def ensure_tracker_exists(path: str):
    """
    If the tracker Excel file does not exist yet, create it with
    a formatted header row and freeze the top row.
    If it already exists, do nothing.
    """
    tracker_path = Path(path)
    tracker_path.parent.mkdir(parents=True, exist_ok=True)

    if tracker_path.exists():
        return  # already exists — nothing to do

    log.info(f"Tracker not found — creating new file at: {path}")

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = SHEET_NAME

    # ── Header row styling ────────────────────────────────────────────────────
    header_fill   = PatternFill("solid", fgColor="1F3864")   # dark navy
    header_font   = Font(color="FFFFFF", bold=True, size=10)
    header_align  = Alignment(horizontal="center", vertical="center", wrap_text=True)
    thin_border   = Border(
        left   = Side(style="thin", color="CCCCCC"),
        right  = Side(style="thin", color="CCCCCC"),
        bottom = Side(style="thin", color="CCCCCC"),
    )

    for col_idx, col_name in enumerate(COLUMNS, start=1):
        cell = ws.cell(row=1, column=col_idx, value=col_name)
        cell.fill      = header_fill
        cell.font      = header_font
        cell.alignment = header_align
        cell.border    = thin_border

    # ── Column widths ─────────────────────────────────────────────────────────
    widths = [18, 18, 22, 10, 16, 10, 12, 12, 36, 22, 32, 12, 20]
    for i, w in enumerate(widths, start=1):
        ws.column_dimensions[openpyxl.utils.get_column_letter(i)].width = w

    ws.row_dimensions[1].height = 30
    ws.freeze_panes = "A2"   # freeze header row

    wb.save(path)
    log.info("Tracker file created successfully.")


def append_row(path: str, data: dict):
    """
    Open the tracker Excel file and append one row with the extracted data.
    Applies alternating row shading for readability.
    """
    wb = openpyxl.load_workbook(path)
    ws = wb[SHEET_NAME]

    next_row = ws.max_row + 1

    # Alternating row colour: white for odd data rows, light grey for even
    row_fill = (
        PatternFill("solid", fgColor="F2F2F2")   # light grey
        if next_row % 2 == 0
        else PatternFill("solid", fgColor="FFFFFF")  # white
    )

    # Status cell colour
    status_colors = {
        "Pending"   : "FFF2CC",   # yellow
        "Complete"  : "E2EFDA",   # green
        "Query"     : "FCE4D6",   # orange
    }

    for key, col_idx in COL_MAP.items():
        value = data.get(key, "")
        cell  = ws.cell(row=next_row, column=col_idx, value=value)
        cell.alignment = Alignment(vertical="center")
        cell.fill      = row_fill

        # Highlight Status cell
        if key == "status":
            status_fill_color = status_colors.get(str(value), "FFF2CC")
            cell.fill = PatternFill("solid", fgColor=status_fill_color)
            cell.font = Font(bold=True, size=10)

        # Right-align amount column
        if key == "amount":
            cell.alignment = Alignment(horizontal="right", vertical="center")
            cell.number_format = '#,##0.00'

    wb.save(path)
    log.info(
        f"Row {next_row} written — NP: {data['np_name']} | "
        f"{data['currency']} {data['amount']:,.2f} | Status: {data['status']}"
    )


# =============================================================================
# STEP 4 — MAIN: READ EMAILS, EXTRACT, WRITE TRACKER, MARK AS READ
# =============================================================================

def run():
    log.info("=" * 70)
    log.info("IGP OAR Payment Tracker — Script started")
    log.info(f"Mailbox  : {MAILBOX_NAME}")
    log.info(f"Tracker  : {TRACKER_PATH}")
    log.info("=" * 70)

    # ── Ensure tracker file exists ────────────────────────────────────────────
    ensure_tracker_exists(TRACKER_PATH)

    # ── Connect to Outlook mailbox ────────────────────────────────────────────
    inbox = get_oar_inbox()

    # ── Filter unread emails only ─────────────────────────────────────────────
    unread_emails = [
        email for email in inbox.Items
        if getattr(email, "UnRead", False)
    ]

    log.info(f"Unread emails found: {len(unread_emails)}")

    if not unread_emails:
        log.info("No new emails to process. Script complete.")
        return

    processed = 0
    skipped   = 0

    for email in unread_emails:
        try:
            # ── Extract data from this email ──────────────────────────────────
            data = extract_oar_payment(email)

            if data is None:
                skipped += 1
                continue

            # ── Write row to tracker ──────────────────────────────────────────
            append_row(TRACKER_PATH, data)

            # ── Mark email as read so it is not processed again ───────────────
            email.UnRead = False
            email.Save()

            processed += 1

        except Exception as e:
            log.error(f"Error processing email '{email.Subject}': {e}")
            skipped += 1
            continue

    # ── Summary ───────────────────────────────────────────────────────────────
    log.info("-" * 70)
    log.info(f"Done. Processed: {processed}  |  Skipped: {skipped}")
    log.info(f"Tracker saved at: {TRACKER_PATH}")
    log.info("=" * 70)


# =============================================================================
# ENTRY POINT
# =============================================================================

if __name__ == "__main__":
    run()
